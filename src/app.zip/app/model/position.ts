export interface Position {
        lat:number,
        lng:number
}
