export interface Today {
        location:string,
        maxtemp:number,
        mintemp:number,
        condition:{text:string,icon:string,code:number}
}
